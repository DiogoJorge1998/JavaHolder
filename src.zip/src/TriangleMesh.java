import java.util.ArrayList;
import java.util.List;

public class TriangleMesh {
	
	  List<Point> pointsList = new ArrayList<Point>();

	  public TriangleMesh(Point[] PArray) {
	    List<Point> pL = new ArrayList<Point>();
	    for (int i=0; i<PArray.length; i++)
	      pL.add(new Point(PArray[i].getX(), PArray[i].getY()));

	    lowerYtoFirst(pL);
	    sortByAngle(pL);
	    pointsList.add(new Point(pL.get(0).getX(), pL.get(0).getY()));
	    pointsList.add(new Point(pL.get(1).getX(), pL.get(1).getY()));
	    pointsList.add(new Point(pL.get(2).getX(), pL.get(2).getY()));
	    for (int i=3; i<pL.size(); i++) {
	      while (ccw(pointsList.get(pointsList.size()-2), pointsList.get(pointsList.size()-1), pL.get(i)) <= 0) {
	        pointsList.remove(pointsList.size()-1);
	        if (pointsList.size() < 2)
	          break;
	      }
	      pointsList.add(new Point(pL.get(i).getX(), pL.get(i).getY()));
	    }
	    //remove colinear extra turn
	    int i=0;
	    while (i<pointsList.size()-2){
	      if (ccw(pointsList.get(0), pointsList.get(1), pointsList.get(2)) == 0){
	          pointsList.remove(1);
	          i=0;
	      }
	      i++;
	    }
	    
	  }

	  public List<Point> getHull() {
	    return pointsList;
	  }

	  private void lowerYtoFirst(List<Point> list) {
	    int index = 0;
	    int y = list.get(0).getY();
	    for (int i=1; i<list.size(); i++) {
	      if (list.get(i).getY() < y || (list.get(i).getY() == y && list.get(i).getX() < list.get(index).getX()) ) {
	        index = i;
	        y = list.get(i).getY();
	      }
	    }
	    swapPoints(list, 0, index);
	  }

	  private double ccw(Point p1, Point p2, Point p3) {
	    return (p2.getX() - p1.getX())*(p3.getY() - p1.getY()) - (p2.getY() - p1.getY())*(p3.getX() - p1.getX());
	  }

	  private void sortByAngle(List<Point> list) {
	    for (int i=1; i<list.size()-1; i++) {
	      for (int j=i+1; j<list.size(); j++) {
	        if (GetAngleOfLineBetweenTwoPoints(list.get(0), list.get(i)) > GetAngleOfLineBetweenTwoPoints(list.get(0), list.get(j)))
	          swapPoints(list, i, j);
	      }
	    }
	  }

	  public double GetAngleOfLineBetweenTwoPoints(Point p1, Point p2) {
	    return Math.toDegrees(Math.atan2(p2.getY() - p1.getY(), p2.getX() - p1.getX()));
	  }

	  private void swapPoints(List<Point> list, int i1, int i2) {
	    Point p = list.get(i1);
	    list.set(i1, list.get(i2));
	    list.set(i2, p);
	  }
}